# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.run:brain_calc',
                     'brain-even = brain_games.scripts.run:brain_even',
                     'brain-gcd = brain_games.scripts.run:brain_gcd',
                     'brain-prime = brain_games.scripts.run:brain_prime',
                     'brain-progression = '
                     'brain_games.scripts.run:brain_progression']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/ReyTris/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ReyTris/python-project-49/actions)\n<a href="https://codeclimate.com/github/ReyTris/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/fefbe3942b89d8715e1e/maintainability" /></a>\n\n1) even https://asciinema.org/a/jaLKHGWiXnvwDJiwmM57EFux8\n\n2) calc https://asciinema.org/a/KEPYqQRLmUA0ydbaUNVURjrCk\n\n3) gcd https://asciinema.org/a/jBIWGrESjEmYbLHfUueinhfWI\n\n4) progression https://asciinema.org/a/Ih86oSYE9pjKSpg9PHZfa5H1D\n\n5) prime https://asciinema.org/a/XpjA3M762hn2MLJTilciXuJPn',
    'author': 'Samsonov Nikita',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
