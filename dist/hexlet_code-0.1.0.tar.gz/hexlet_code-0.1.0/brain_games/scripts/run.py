#!/usr/bin/env python3
from brain_games.games.engine_game import engine

from brain_games.games import even_game

def brain_even():
    engine(even_game)