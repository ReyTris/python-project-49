from brain_games.cli import welcome_user

def welcome_game():
    welcome_user()