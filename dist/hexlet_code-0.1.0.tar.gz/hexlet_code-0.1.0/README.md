### Hexlet tests and linter status:
[![Actions Status](https://github.com/ReyTris/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ReyTris/python-project-49/actions)
<a href="https://codeclimate.com/github/ReyTris/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/fefbe3942b89d8715e1e/maintainability" /></a>

1) even https://asciinema.org/a/aj2h4CAXEBJ7xYyJJyJcUuFGR"

2) calc https://asciinema.org/a/KEPYqQRLmUA0ydbaUNVURjrCk

3) gcd https://asciinema.org/a/jBIWGrESjEmYbLHfUueinhfWI